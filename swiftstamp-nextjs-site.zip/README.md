# SwiftStamp Notary Site

A simple Next.js site for SwiftStamp Notary Services.